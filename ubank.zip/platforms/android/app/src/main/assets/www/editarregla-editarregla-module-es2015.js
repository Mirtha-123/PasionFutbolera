(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["editarregla-editarregla-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/editarregla/editarregla.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/editarregla/editarregla.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Regla Edicion Pasion Futbolera</ion-title>\n    <ion-buttons slot=\"start\">\n    \t<ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<ion-list>\n  <ion-list-header>\n    <ion-label>\n      \n    </ion-label>\n  </ion-list-header>\n\n\n  <ion-item>\n    <ion-label>Equipo</ion-label>\n    <ion-select value=\"1\" okText=\"Elegir\" cancelText=\"Cancelar\" name=\"tipo1\" [(ngModel)]=\"futbolero\">\n      <ion-select-option [value]=\"x\" *ngFor=\"let x of equipos1\">{{x.shortName}}</ion-select-option>\n     \n    </ion-select>\n  </ion-item>\n  <ion-item>\n    <ion-label>Evento</ion-label>\n    <ion-select value=\"1\" okText=\"Elegir\" cancelText=\"Cancelar\" name=\"tipo1\" [(ngModel)]=\"edicion.evento\">\n      <ion-select-option value=\"9\">Jugar</ion-select-option>\n      <ion-select-option value=\"8\">Ganar</ion-select-option>\n      <ion-select-option value=\"7\">Por cada Gol</ion-select-option>\n      \n    </ion-select>\n  </ion-item>\n\n<ion-item>\n  <ion-label position=\"fixed\">Monto a Ahorrar $</ion-label>\n  <ion-input type=\"number\" name=\"monto1\" min=\"0\" pattern=\"^[0-9]+\" [(ngModel)]=\"edicion.monto\"></ion-input>\n</ion-item>\n<ion-button expand=\"full\" color=\"tertiary\" (click)=\"actualizar()\">Editar</ion-button>\n</ion-list>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/editarregla/editarregla-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/editarregla/editarregla-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: EditarreglaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditarreglaPageRoutingModule", function() { return EditarreglaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _editarregla_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./editarregla.page */ "./src/app/editarregla/editarregla.page.ts");




const routes = [
    {
        path: '',
        component: _editarregla_page__WEBPACK_IMPORTED_MODULE_3__["EditarreglaPage"]
    }
];
let EditarreglaPageRoutingModule = class EditarreglaPageRoutingModule {
};
EditarreglaPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditarreglaPageRoutingModule);



/***/ }),

/***/ "./src/app/editarregla/editarregla.module.ts":
/*!***************************************************!*\
  !*** ./src/app/editarregla/editarregla.module.ts ***!
  \***************************************************/
/*! exports provided: EditarreglaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditarreglaPageModule", function() { return EditarreglaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _editarregla_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./editarregla-routing.module */ "./src/app/editarregla/editarregla-routing.module.ts");
/* harmony import */ var _editarregla_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./editarregla.page */ "./src/app/editarregla/editarregla.page.ts");







let EditarreglaPageModule = class EditarreglaPageModule {
};
EditarreglaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _editarregla_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditarreglaPageRoutingModule"]
        ],
        declarations: [_editarregla_page__WEBPACK_IMPORTED_MODULE_6__["EditarreglaPage"]]
    })
], EditarreglaPageModule);



/***/ }),

/***/ "./src/app/editarregla/editarregla.page.scss":
/*!***************************************************!*\
  !*** ./src/app/editarregla/editarregla.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VkaXRhcnJlZ2xhL2VkaXRhcnJlZ2xhLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/editarregla/editarregla.page.ts":
/*!*************************************************!*\
  !*** ./src/app/editarregla/editarregla.page.ts ***!
  \*************************************************/
/*! exports provided: EditarreglaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditarreglaPage", function() { return EditarreglaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "./node_modules/@ionic-native/native-storage/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _api_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../api/api.service */ "./src/app/api/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");






let EditarreglaPage = class EditarreglaPage {
    constructor(nativeStorage, rutaActiva, api, nave) {
        this.nativeStorage = nativeStorage;
        this.rutaActiva = rutaActiva;
        this.api = api;
        this.nave = nave;
        this.edicion = {};
        this.equipos1 = [];
    }
    ngOnInit() {
        this.api.listaequipo().subscribe((data) => {
            console.log(data);
            this.equipos1 = data.teams;
        });
        this.pa = this.rutaActiva.snapshot.paramMap.get("regla");
        this.nativeStorage.getItem(this.pa)
            .then(data => {
            this.edicion = data;
            this.futbolero = data.nomequipo;
            console.log(data);
        }, error => console.error(error));
    }
    actualizar() {
        this.edicion.nomequipo = this.futbolero.shortName;
        this.edicion.idequipo = this.futbolero.id;
        console.log(this.edicion);
        this.nativeStorage.setItem(this.pa, this.edicion)
            .then(() => {
            console.log('Actualizado');
            this.nave.navigateForward('');
        }, error => console.error('Error storing item', error));
    }
};
EditarreglaPage.ctorParameters = () => [
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
EditarreglaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-editarregla',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./editarregla.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/editarregla/editarregla.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./editarregla.page.scss */ "./src/app/editarregla/editarregla.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]])
], EditarreglaPage);



/***/ })

}]);
//# sourceMappingURL=editarregla-editarregla-module-es2015.js.map