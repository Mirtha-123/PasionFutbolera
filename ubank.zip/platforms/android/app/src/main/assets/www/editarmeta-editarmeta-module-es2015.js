(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["editarmeta-editarmeta-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/editarmeta/editarmeta.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/editarmeta/editarmeta.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Editar Meta {{edicion}}\n      <ion-buttons slot=\"start\">\n    \t<ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  \n\n<ion-content>\n<ion-list>\n  <ion-list-header>\n    <ion-label>\n      \n    </ion-label>\n  </ion-list-header>\n\n\n  <ion-item>\n    <ion-label>Tipo de Meta</ion-label>\n    <ion-select value=\"1\" okText=\"Elegir\" cancelText=\"Cancelar\" name=\"tipo1\" [(ngModel)]=\"edicion.tipo\">\n      <ion-select-option value=\"1\">Comprar Algo</ion-select-option>\n      <ion-select-option value=\"2\">Viajar</ion-select-option>\n      <ion-select-option value=\"3\">Hacer Algo</ion-select-option>\n      <ion-select-option value=\"4\">Solo Ahorrar</ion-select-option>\n    </ion-select>\n  </ion-item>\n <ion-item>\n  <ion-label position=\"floating\">MM/DD/YYYY</ion-label>\n  <ion-datetime displayFormat=\"MMMM/DD\" [min]=\"periodo\" name=\"date1\" [(ngModel)]=\"edicion.fecha\" ></ion-datetime>\n</ion-item>\n<ion-item>\n  <ion-label position=\"fixed\">Monto a Ahorrar</ion-label>\n  <ion-input type=\"number\" name=\"monto1\" min=\"0\"  pattern=\"^[0-9]+\" [(ngModel)]=\"edicion.monto\"></ion-input>\n</ion-item>\n<ion-button expand=\"full\" color=\"tertiary\" (click)=\"actualizar()\">Actualizar</ion-button>\n\n</ion-list>\n</ion-content>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/editarmeta/editarmeta-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/editarmeta/editarmeta-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: EditarmetaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditarmetaPageRoutingModule", function() { return EditarmetaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _editarmeta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./editarmeta.page */ "./src/app/editarmeta/editarmeta.page.ts");




const routes = [
    {
        path: '',
        component: _editarmeta_page__WEBPACK_IMPORTED_MODULE_3__["EditarmetaPage"]
    }
];
let EditarmetaPageRoutingModule = class EditarmetaPageRoutingModule {
};
EditarmetaPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditarmetaPageRoutingModule);



/***/ }),

/***/ "./src/app/editarmeta/editarmeta.module.ts":
/*!*************************************************!*\
  !*** ./src/app/editarmeta/editarmeta.module.ts ***!
  \*************************************************/
/*! exports provided: EditarmetaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditarmetaPageModule", function() { return EditarmetaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _editarmeta_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./editarmeta-routing.module */ "./src/app/editarmeta/editarmeta-routing.module.ts");
/* harmony import */ var _editarmeta_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./editarmeta.page */ "./src/app/editarmeta/editarmeta.page.ts");







let EditarmetaPageModule = class EditarmetaPageModule {
};
EditarmetaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _editarmeta_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditarmetaPageRoutingModule"]
        ],
        declarations: [_editarmeta_page__WEBPACK_IMPORTED_MODULE_6__["EditarmetaPage"]]
    })
], EditarmetaPageModule);



/***/ }),

/***/ "./src/app/editarmeta/editarmeta.page.scss":
/*!*************************************************!*\
  !*** ./src/app/editarmeta/editarmeta.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2VkaXRhcm1ldGEvZWRpdGFybWV0YS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/editarmeta/editarmeta.page.ts":
/*!***********************************************!*\
  !*** ./src/app/editarmeta/editarmeta.page.ts ***!
  \***********************************************/
/*! exports provided: EditarmetaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditarmetaPage", function() { return EditarmetaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "./node_modules/@ionic-native/native-storage/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _api_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../api/api.service */ "./src/app/api/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");






let EditarmetaPage = class EditarmetaPage {
    constructor(nativeStorage, rutaActiva, api, nave) {
        this.nativeStorage = nativeStorage;
        this.rutaActiva = rutaActiva;
        this.api = api;
        this.nave = nave;
        this.edicion = {};
    }
    ngOnInit() {
        console.log(this.rutaActiva.snapshot.paramMap.get("papi"));
        this.pa = this.rutaActiva.snapshot.paramMap.get("papi");
        this.nativeStorage.getItem(this.pa)
            .then(data => {
            this.edicion = data;
        }, error => console.error(error));
    }
    actualizar() {
        console.log(this.edicion);
        this.nativeStorage.setItem(this.pa, this.edicion)
            .then(() => {
            console.log('Actualizado');
            this.nave.navigateForward('');
        }, error => console.error('Error storing item', error));
    }
};
EditarmetaPage.ctorParameters = () => [
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
EditarmetaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-editarmeta',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./editarmeta.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/editarmeta/editarmeta.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./editarmeta.page.scss */ "./src/app/editarmeta/editarmeta.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]])
], EditarmetaPage);



/***/ })

}]);
//# sourceMappingURL=editarmeta-editarmeta-module-es2015.js.map