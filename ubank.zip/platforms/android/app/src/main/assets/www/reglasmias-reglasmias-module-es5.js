function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reglasmias-reglasmias-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/reglasmias/reglasmias.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/reglasmias/reglasmias.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReglasmiasReglasmiasPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      <strong>Reglas</strong>\n\n    </ion-title>\n    <ion-buttons slot=\"start\">\n    \t<ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n \n\n<ion-list>\n \n\n\n  <ion-list>\n  \t\n  <ion-item *ngFor=\"let x of reglas;let i = index\"  [ngSwitch]=\"x.evento\">\n    \n    <ion-label *ngSwitchCase=\"'9'\"><h2>{{x.nomequipo}}</h2>  <h3>Evento: Jugar</h3>\n    <p>Monto a ahorrar:{{x.monto}} </p><ion-button color=\"primary\" (click)=\"editar(x)\">Editar</ion-button>\n   </ion-label>\n    <ion-label *ngSwitchCase=\"'8'\"><h2>{{x.nomequipo}}</h2>  <h3>Evento: Ganar</h3>\n    <p>Monto a ahorrar:{{x.monto}} </p><ion-button color=\"primary\" (click)=\"editar(x)\">Editar</ion-button>\n   </ion-label>\n   <ion-label *ngSwitchCase=\"'7'\"><h2>{{x.nomequipo}}</h2>  <h3>Evento: Por Gol</h3>\n    <p>Monto a ahorrar:{{x.monto}} </p><ion-button color=\"primary\" (click)=\"editar(x)\">Editar</ion-button>\n   </ion-label>\n  </ion-item>\n  \n</ion-list>\n\n\n \n</ion-list>\n\n <!-- <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Tab 1</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <app-explore-container name=\"Tab 1 page\"></app-explore-container>-->\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/reglasmias/reglasmias-routing.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/reglasmias/reglasmias-routing.module.ts ***!
    \*********************************************************/

  /*! exports provided: ReglasmiasPageRoutingModule */

  /***/
  function srcAppReglasmiasReglasmiasRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReglasmiasPageRoutingModule", function () {
      return ReglasmiasPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _reglasmias_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./reglasmias.page */
    "./src/app/reglasmias/reglasmias.page.ts");

    var routes = [{
      path: '',
      component: _reglasmias_page__WEBPACK_IMPORTED_MODULE_3__["ReglasmiasPage"]
    }];

    var ReglasmiasPageRoutingModule = function ReglasmiasPageRoutingModule() {
      _classCallCheck(this, ReglasmiasPageRoutingModule);
    };

    ReglasmiasPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReglasmiasPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/reglasmias/reglasmias.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/reglasmias/reglasmias.module.ts ***!
    \*************************************************/

  /*! exports provided: ReglasmiasPageModule */

  /***/
  function srcAppReglasmiasReglasmiasModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReglasmiasPageModule", function () {
      return ReglasmiasPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _reglasmias_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./reglasmias-routing.module */
    "./src/app/reglasmias/reglasmias-routing.module.ts");
    /* harmony import */


    var _reglasmias_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./reglasmias.page */
    "./src/app/reglasmias/reglasmias.page.ts");

    var ReglasmiasPageModule = function ReglasmiasPageModule() {
      _classCallCheck(this, ReglasmiasPageModule);
    };

    ReglasmiasPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _reglasmias_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReglasmiasPageRoutingModule"]],
      declarations: [_reglasmias_page__WEBPACK_IMPORTED_MODULE_6__["ReglasmiasPage"]]
    })], ReglasmiasPageModule);
    /***/
  },

  /***/
  "./src/app/reglasmias/reglasmias.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/reglasmias/reglasmias.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReglasmiasReglasmiasPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlZ2xhc21pYXMvcmVnbGFzbWlhcy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/reglasmias/reglasmias.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/reglasmias/reglasmias.page.ts ***!
    \***********************************************/

  /*! exports provided: ReglasmiasPage */

  /***/
  function srcAppReglasmiasReglasmiasPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReglasmiasPage", function () {
      return ReglasmiasPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/native-storage/ngx */
    "./node_modules/@ionic-native/native-storage/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _api_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../api/api.service */
    "./src/app/api/api.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var ReglasmiasPage =
    /*#__PURE__*/
    function () {
      function ReglasmiasPage(nativeStorage, rutaActiva, modalController, api, nave) {
        _classCallCheck(this, ReglasmiasPage);

        this.nativeStorage = nativeStorage;
        this.rutaActiva = rutaActiva;
        this.modalController = modalController;
        this.api = api;
        this.nave = nave;
        this.id = 0;
        this.x = new Date();
        this.meta = {};
        this.elementos = [];
        this.reglas = [];
      }

      _createClass(ReglasmiasPage, [{
        key: "ref",
        value: function ref() {
          console.log(this.reglas);
        }
      }, {
        key: "editar",
        value: function editar(x) {
          console.log(x);
          this.nave.navigateForward("editarregla/".concat(x.miregla));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.pa = this.rutaActiva.snapshot.paramMap.get("dame");
          var items = [];
          this.nativeStorage.keys().then(function (data) {
            items = data;

            for (var i = items.length - 1; i >= 0; i--) {
              var t = items[i].split('-');

              if (t[0] == 'r') {
                _this.nativeStorage.getItem(items[i]).then(function (data) {
                  console.log(data.meta);
                  console.log(_this.pa);

                  if (data.meta == _this.pa) {
                    console.log('entro');

                    _this.reglas.push(data);
                  }

                  console.log(data);
                }, function (error) {
                  return console.error(error);
                });
              }
            }
          }, function (error) {
            return console.error(error);
          });
        }
      }]);

      return ReglasmiasPage;
    }();

    ReglasmiasPage.ctorParameters = function () {
      return [{
        type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }];
    };

    ReglasmiasPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-reglasmias',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./reglasmias.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/reglasmias/reglasmias.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./reglasmias.page.scss */
      "./src/app/reglasmias/reglasmias.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])], ReglasmiasPage);
    /***/
  }
}]);
//# sourceMappingURL=reglasmias-reglasmias-module-es5.js.map