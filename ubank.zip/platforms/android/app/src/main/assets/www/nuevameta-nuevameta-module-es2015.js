(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["nuevameta-nuevameta-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/nuevameta/nuevameta.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nuevameta/nuevameta.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Nueva Meta \n      <ion-buttons slot=\"start\">\n    \t<ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  \n\n<ion-content>\n<ion-list>\n  <ion-list-header>\n    <ion-label>\n      \n    </ion-label>\n  </ion-list-header>\n\n\n  <ion-item>\n    <ion-label>Tipo de Meta</ion-label>\n    <ion-select value=\"1\" okText=\"Elegir\" cancelText=\"Cancelar\" name=\"tipo\" [(ngModel)]=\"meta.tipo\" >\n      <ion-select-option value=\"1\">Comprar Algo</ion-select-option>\n      <ion-select-option value=\"2\">Viajar</ion-select-option>\n      <ion-select-option value=\"3\">Hacer Algo</ion-select-option>\n      <ion-select-option value=\"4\">Solo Ahorrar</ion-select-option>\n    </ion-select>\n  </ion-item>\n <ion-item>\n  <ion-label position=\"floating\">MM/DD/YYYY</ion-label>\n  <ion-datetime displayFormat=\"MMMM/DD\" [min]=\"periodo\" name=\"date\" [(ngModel)]=\"ayuda\" ></ion-datetime>\n</ion-item>\n<ion-item>\n  <ion-label position=\"fixed\">Monto a Ahorrar</ion-label>\n  <ion-input type=\"number\" name=\"monto\" min=\"0\" pattern=\"^[0-9]+\" [(ngModel)]=\"meta.monto\"></ion-input>\n</ion-item>\n<ion-button expand=\"full\" color=\"tertiary\" (click)=\"guardar()\">Guardar</ion-button>\n\n</ion-list>\n</ion-content>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/nuevameta/nuevameta-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/nuevameta/nuevameta-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: NuevametaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NuevametaPageRoutingModule", function() { return NuevametaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _nuevameta_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./nuevameta.page */ "./src/app/nuevameta/nuevameta.page.ts");




const routes = [
    {
        path: '',
        component: _nuevameta_page__WEBPACK_IMPORTED_MODULE_3__["NuevametaPage"]
    }
];
let NuevametaPageRoutingModule = class NuevametaPageRoutingModule {
};
NuevametaPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NuevametaPageRoutingModule);



/***/ }),

/***/ "./src/app/nuevameta/nuevameta.module.ts":
/*!***********************************************!*\
  !*** ./src/app/nuevameta/nuevameta.module.ts ***!
  \***********************************************/
/*! exports provided: NuevametaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NuevametaPageModule", function() { return NuevametaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _nuevameta_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./nuevameta-routing.module */ "./src/app/nuevameta/nuevameta-routing.module.ts");
/* harmony import */ var _nuevameta_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./nuevameta.page */ "./src/app/nuevameta/nuevameta.page.ts");







let NuevametaPageModule = class NuevametaPageModule {
};
NuevametaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _nuevameta_routing_module__WEBPACK_IMPORTED_MODULE_5__["NuevametaPageRoutingModule"]
        ],
        declarations: [_nuevameta_page__WEBPACK_IMPORTED_MODULE_6__["NuevametaPage"]]
    })
], NuevametaPageModule);



/***/ }),

/***/ "./src/app/nuevameta/nuevameta.page.scss":
/*!***********************************************!*\
  !*** ./src/app/nuevameta/nuevameta.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL251ZXZhbWV0YS9udWV2YW1ldGEucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/nuevameta/nuevameta.page.ts":
/*!*********************************************!*\
  !*** ./src/app/nuevameta/nuevameta.page.ts ***!
  \*********************************************/
/*! exports provided: NuevametaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NuevametaPage", function() { return NuevametaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "./node_modules/@ionic-native/native-storage/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");




let NuevametaPage = class NuevametaPage {
    constructor(nativeStorage, nave) {
        this.nativeStorage = nativeStorage;
        this.nave = nave;
        this.ayuda = new Date();
        this.x = new Date();
        this.meta = {};
        this.mas = 0;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.x = new Date();
        var items = [];
        this.nativeStorage.keys()
            .then(data => {
            items = data;
            for (var i = items.length - 1; i >= 0; i--) {
                var t = items[i].split('-');
                if (t[0] == 'm') {
                    this.mas++;
                }
            }
            console.log(items.length);
            if (this.mas >= 1) {
                this.id = this.mas + 1;
            }
            else {
                this.id = 1;
            }
        }, error => console.error(error));
        this.x.setDate(parseFloat(this.x.getDate()) + 30);
        this.periodo = this.x.getFullYear() + '-' + ('0' + (this.x.getMonth() + 1)).slice(-2) +
            '-' + ('0' + this.x.getDate()).slice(-2);
    }
    guardar() {
        console.log(this.meta);
        this.meta.fecha = this.ayuda;
        var u = 'm-' + String(this.id);
        this.meta.nombre = u;
        this.nativeStorage.setItem(u, this.meta)
            .then(() => {
            this.id = this.id + 1;
            console.log('Guarde' + u);
            this.nave.navigateForward('');
        }, error => console.error('Error storing item', error));
        this.nativeStorage.getItem(this.id)
            .then(data => console.log(data), error => console.error(error));
    }
};
NuevametaPage.ctorParameters = () => [
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] }
];
NuevametaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-nuevameta',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./nuevameta.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/nuevameta/nuevameta.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./nuevameta.page.scss */ "./src/app/nuevameta/nuevameta.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
], NuevametaPage);



/***/ })

}]);
//# sourceMappingURL=nuevameta-nuevameta-module-es2015.js.map