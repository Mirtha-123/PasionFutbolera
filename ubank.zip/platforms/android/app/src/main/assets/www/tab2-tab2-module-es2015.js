(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab2-tab2-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tab2/tab2.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tab2/tab2.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Simulacion\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  \n\n<ion-content>\n  <ion-list>\n  <ion-header class=\"headw\">\n    <h3>Totales</h3>\n  </ion-header>\n  <ion-item *ngFor=\"let x of reglasuma\" color=\"secondary\">\n    <ion-label><h2>Regla:{{x.regla}}</h2><h3>Cuantos veces se activo:{{x.activacion}} </h3> <h4>Monto ganado:{{x.jugar}} </h4></ion-label> \n  </ion-item>\n \n</ion-list>\n<ion-list>\n  <ion-header>\n    Goleados\n  </ion-header>\n  <ion-item *ngFor=\"let x of goleados\" color=\"primary\">\n    <ion-label><p>GOLES:{{ x.ahorrado }} por anotar {{ x.goles }} contra {{ x.contra }} el día {{ x.fecha | date }}  </p> </ion-label> \n  </ion-item>\n \n</ion-list>\n<ion-list>\n  <ion-header>\n    Ganados\n  </ion-header>\n  <ion-item *ngFor=\"let x of ganados\" color=\"success\">\n    <ion-label>GANAR: {{ x.ahorrado }} ahorrado por ganar contra {{ x.contra }} el día {{ x.fecha | date }}</ion-label> \n  </ion-item>\n \n</ion-list>\n<ion-list>\n  <ion-header>\n    Jugados\n  </ion-header>\n  <ion-item *ngFor=\"let x of jugados\" color=\"warning\">\n    <ion-label>JUGAR: {{ x.ahorrado }} ahorrado por ganar contra {{ x.contra }} el día {{ x.fecha | date }}</ion-label> \n  </ion-item>\n \n</ion-list>\n</ion-content>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/tab2/tab2.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/*! exports provided: Tab2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2PageModule", function() { return Tab2PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab2.page */ "./src/app/tab2/tab2.page.ts");
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../explore-container/explore-container.module */ "./src/app/explore-container/explore-container.module.ts");








let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_7__["ExploreContainerComponentModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"] }])
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"]]
    })
], Tab2PageModule);



/***/ }),

/***/ "./src/app/tab2/tab2.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content ion-toolbar {\n  --background: translucent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMi9DOlxcVXNlcnNcXEFudG9uaW9cXERlc2t0b3BcXHViYW5rXFx1YmFuay9zcmNcXGFwcFxcdGFiMlxcdGFiMi5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYjIvdGFiMi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5QkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvdGFiMi90YWIyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc2x1Y2VudDtcbiAgLmhlYWR3e31cbn0iLCJpb24tY29udGVudCBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNsdWNlbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/tab2/tab2.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/*! exports provided: Tab2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2Page", function() { return Tab2Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "./node_modules/@ionic-native/native-storage/ngx/index.js");
/* harmony import */ var _api_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api/api.service */ "./src/app/api/api.service.ts");




let Tab2Page = class Tab2Page {
    constructor(nativeStorage, api) {
        this.nativeStorage = nativeStorage;
        this.api = api;
        this.ayuda = new Date();
        this.x = new Date();
        this.meta = {};
        this.partidos = [];
        this.reglasuma = [];
        this.jugados = [];
        this.ganados = [];
        this.goleados = [];
    }
    ngOnInit() {
        this.api.listadepartidos().subscribe((data) => {
            console.log(data);
            this.partidos = data.matches;
            for (var i = this.partidos.length - 1; i >= 0; i--) {
                if (this.partidos[i].homeTeam.id == 102) {
                    console.log(this.partidos[i]);
                }
                if (this.partidos[i].awayTeam.id == 102) {
                    console.log(this.partidos[i]);
                }
            }
            //
            var items = [];
            this.nativeStorage.keys()
                .then(data => {
                console.log(data);
                items = data;
                for (var i = items.length - 1; i >= 0; i--) {
                    var t = items[i].split('-');
                    if (t[0] == 'r') {
                        this.nativeStorage.getItem(items[i])
                            .then(data => {
                            var porjugar = 0;
                            var activacion = 0;
                            var goles = 0;
                            for (var ia = this.partidos.length - 1; ia >= 0; ia--) {
                                var cuentas = 0;
                                if (this.partidos[ia].homeTeam.id == data.idequipo) {
                                    switch (data.evento) {
                                        case "9":
                                            var juguito = 0;
                                            activacion = activacion + 1;
                                            porjugar = parseFloat(porjugar) + parseFloat(data.monto);
                                            juguito = parseFloat(data.monto);
                                            var h1 = {
                                                ahorrado: juguito,
                                                contra: this.partidos[ia].awayTeam.name,
                                                fecha: this.partidos[ia].utcDate
                                            };
                                            this.jugados.push(h1);
                                            break;
                                        case "8":
                                            if (this.partidos[ia].score.winner == 'HOME_TEAM') {
                                                var gana = 0;
                                                activacion = activacion + 1;
                                                porjugar = parseFloat(porjugar) + parseFloat(data.monto);
                                                gana = parseFloat(data.monto);
                                                var h2 = {
                                                    ahorrado: gana,
                                                    contra: this.partidos[ia].awayTeam.name,
                                                    fecha: this.partidos[ia].utcDate
                                                };
                                                this.ganados.push(h2);
                                            }
                                            // code...
                                            break;
                                        case "7":
                                            var golesillo = 0;
                                            var mimo = 0;
                                            golesillo = golesillo + parseFloat(this.partidos[ia].score.fullTime.homeTeam) + parseFloat(this.partidos[ia].score.fullTime.homeTeam);
                                            cuentas = cuentas + parseFloat(this.partidos[ia].score.fullTime.homeTeam);
                                            cuentas = cuentas + parseFloat(this.partidos[ia].score.fullTime.homeTeam);
                                            if (this.partidos[ia].score.extraTime.homeTeam != null) {
                                                golesillo = golesillo + parseFloat(this.partidos[ia].score.extraTime.homeTeam);
                                                cuentas = cuentas + parseFloat(this.partidos[ia].score.extraTime.homeTeam);
                                            }
                                            porjugar = parseFloat(porjugar) + (parseFloat(cuentas) * parseFloat(data.monto));
                                            mimo = (parseFloat(golesillo) * parseFloat(data.monto));
                                            var xz = {
                                                ahorrado: mimo,
                                                contra: this.partidos[ia].awayTeam.name,
                                                fecha: this.partidos[ia].utcDate,
                                                goles: golesillo
                                            };
                                            this.goleados.push(xz);
                                            break;
                                        default:
                                            // code...
                                            break;
                                    }
                                }
                                if (this.partidos[ia].awayTeam.id == data.idequipo) {
                                    switch (data.evento) {
                                        case "9":
                                            var juguito1 = 0;
                                            activacion = activacion + 1;
                                            porjugar = parseFloat(porjugar) + parseFloat(data.monto);
                                            juguito1 = parseFloat(data.monto);
                                            var h3 = {
                                                ahorrado: juguito1,
                                                contra: this.partidos[ia].homeTeam.name,
                                                fecha: this.partidos[ia].utcDate
                                            };
                                            this.jugados.push(h3);
                                            break;
                                        case "8":
                                            if (this.partidos[ia].score.winner == 'AWAY_TEAM') {
                                                var gana1 = 0;
                                                activacion = activacion + 1;
                                                porjugar = parseFloat(porjugar) + parseFloat(data.monto);
                                                gana = parseFloat(data.monto);
                                                var h4 = {
                                                    ahorrado: gana,
                                                    contra: this.partidos[ia].awayTeam.name,
                                                    fecha: this.partidos[ia].utcDate
                                                };
                                                this.ganados.push(h4);
                                            }
                                            break;
                                        case "7":
                                            var golesillo1 = 0;
                                            var mimo1 = 0;
                                            mimo1 = mimo1 + (parseFloat(golesillo) * parseFloat(data.monto));
                                            golesillo1 = golesillo1 + parseFloat(this.partidos[ia].score.fullTime.awayTeam) + parseFloat(this.partidos[ia].score.fullTime.awayTeam);
                                            cuentas = cuentas + parseFloat(this.partidos[ia].score.fullTime.awayTeam);
                                            cuentas = cuentas + parseFloat(this.partidos[ia].score.fullTime.awayTeam);
                                            if (this.partidos[ia].score.extraTime.awayTeam != null) {
                                                golesillo1 = golesillo1 + parseFloat(this.partidos[ia].score.extraTime.homeTeam);
                                                cuentas = cuentas + parseFloat(this.partidos[ia].score.extraTime.awayTeam);
                                            }
                                            mimo1 = (parseFloat(golesillo1) * parseFloat(data.monto));
                                            porjugar = parseFloat(porjugar) + (parseFloat(cuentas) * parseFloat(data.monto));
                                            var qw = {
                                                ahorrado: mimo1,
                                                contra: this.partidos[ia].homeTeam.name,
                                                fecha: this.partidos[ia].utcDate,
                                                goles: cuentas
                                            };
                                            this.goleados.push(qw);
                                            break;
                                        default:
                                            // code...
                                            break;
                                    }
                                }
                                if (data.evento == '7') {
                                    activacion = activacion + cuentas;
                                }
                            }
                            var er = {
                                jugar: porjugar,
                                regla: data.miregla,
                                activacion: activacion
                            };
                            this.reglasuma.push(er);
                            console.log(this.reglasuma);
                            console.log(this.goleados);
                        }, error => console.error(error));
                    }
                }
            }, error => console.error(error));
        });
    }
};
Tab2Page.ctorParameters = () => [
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"] },
    { type: _api_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] }
];
Tab2Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tab2',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tab2.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tab2/tab2.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tab2.page.scss */ "./src/app/tab2/tab2.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_2__["NativeStorage"], _api_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]])
], Tab2Page);



/***/ })

}]);
//# sourceMappingURL=tab2-tab2-module-es2015.js.map